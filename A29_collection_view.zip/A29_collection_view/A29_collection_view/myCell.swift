//
//  myCell.swift
//  A29_collection_view
//
//  Created by exam on 10/7/22.
//  Copyright © 2022 gls. All rights reserved.
//

import UIKit

class myCell: UICollectionViewCell {
    
    @IBOutlet weak var salary: UILabel!
    @IBOutlet weak var name: UILabel!
}
