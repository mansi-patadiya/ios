//
//  Employee.swift
//  A29_collection_view
//
//  Created by exam on 10/7/22.
//  Copyright © 2022 gls. All rights reserved.
//

import UIKit

class Employee: NSObject {

    var empName=""
    var empsalary=0.0
}
