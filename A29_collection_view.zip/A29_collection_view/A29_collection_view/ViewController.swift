//
//  ViewController.swift
//  A29_collection_view
//
//  Created by exam on 10/7/22.
//  Copyright © 2022 gls. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var esalary: UITextField!
    @IBOutlet weak var ename: UITextField!
    var appDel = UIApplication.shared.delegate as! AppDelegate
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addAction(_ sender: Any)
    {
        var empObj = Employee()
        empObj.empName = ename.text!
        empObj.empsalary = Double(esalary.text!)!
        
        appDel.empArray.append(empObj)
        print(appDel.empArray.count)
    }

    @IBAction func nextAction(_ sender: Any)
    {
        performSegue(withIdentifier: "next", sender: self)
    }
}

