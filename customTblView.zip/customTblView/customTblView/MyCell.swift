//
//  MyCell.swift
//  customTblView
//
//  Created by exam on 26/09/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class MyCell: UITableViewCell {

    @IBOutlet weak var studentname: UILabel!
    
    @IBOutlet weak var companyname: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
