//
//  Student.swift
//  customTblView
//
//  Created by exam on 26/09/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class Student: NSObject {
    var name = ""
    var orgName = ""

}
