//
//  ViewController.swift
//  customTblView
//
//  Created by exam on 26/09/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var studData = [Student]()
    
    
    @IBOutlet weak var stuName: UITextField!
    
    @IBOutlet weak var companyName: UITextField!
    
    
    @IBAction func addData(_ sender: Any) {
        let obj = Student()
        obj.name = stuName.text!
        obj.orgName = companyName.text!
        studData.append(obj)
        objLabel.text = String(studData.count)
    }
    
    @IBOutlet weak var objLabel: UILabel!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var send = segue.destination as! displayData
        send.getData = studData
    }
    
    
   
    
    @IBAction func viewData(_ sender: Any)
    {
        performSegue(withIdentifier: "showdetails", sender: self)
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

