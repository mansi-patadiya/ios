//
//  myCell.swift
//  A29_coreData
//
//  Created by exam on 10/7/22.
//  Copyright © 2022 gls. All rights reserved.
//

import UIKit

class myCell: UITableViewCell {

    @IBOutlet weak var salary: UILabel!
    @IBOutlet weak var designation: UILabel!
    @IBOutlet weak var name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
