//
//  ViewController.swift
//  A29_coreData
//
//  Created by exam on 10/7/22.
//  Copyright © 2022 gls. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var salary: UITextField!
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var desg: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func nextAction(_ sender: Any) {
        performSegue(withIdentifier: "next", sender: self)
    }
    
    
    @IBAction func addAction(_ sender: Any) {
        //1.
        var appDel = UIApplication.shared.delegate as! AppDelegate
        //2. Helper class
        var context = appDel.persistentContainer.viewContext
//        3. create table
        var entity = NSEntityDescription.entity(forEntityName: "Employee", in: context)
//        4. create blank row
        let employee = NSManagedObject(entity: entity!, insertInto: context)
//        5. set value in this row
        employee.setValue(name.text, forKey: "name")
        employee.setValue(desg.text, forKey: "designation")
        employee.setValue(Double(salary.text!), forKey: "salary")
//        commit
        do {
            try context.save()
            print("Added")
        } catch let err as NSError {
            print(err)
        }
    }

}

