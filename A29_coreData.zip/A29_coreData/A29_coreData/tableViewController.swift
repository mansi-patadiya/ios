//
//  tableViewController.swift
//  A29_coreData
//
//  Created by exam on 10/7/22.
//  Copyright © 2022 gls. All rights reserved.
//

import UIKit
import CoreData

class tableViewController: UIViewController,UITableViewDataSource {

//    1.
    var appDel:AppDelegate! = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        appDel = UIApplication.shared.delegate as! AppDelegate
//        2.
        var context=appDel.persistentContainer.viewContext
//        3.
        var fetchReq=NSFetchRequest<NSManagedObject>(entityName: "Employee")
//        4.
        
        do {
            try appDel.stuArr = context.fetch(fetchReq)
        } catch var err as NSError {
            print(err)
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appDel.stuArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! myCell
        cell.name.text = appDel.stuArr[indexPath.row].value(forKey: "name") as! String
        cell.designation.text = appDel.stuArr[indexPath.row].value(forKey: "designation") as! String
        var sal = String(describing: appDel.stuArr[indexPath.row].value(forKey: "salary"))
        cell.salary.text = sal as! String
        return cell
        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
