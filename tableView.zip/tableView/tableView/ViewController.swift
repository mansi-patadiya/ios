//
//  ViewController.swift
//  tableView
//
//  Created by exam on 19/09/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var carData = [car]()

    @IBOutlet weak var carname: UITextField!
    @IBOutlet weak var carprice: UITextField!
    
    
    @IBAction func addCar(_ sender: Any) {
        let obj = car()
        obj.name = carname.text!
        obj.price = Int(carprice.text!)!
        carData.append(obj)
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var send = segue.destination as! showCar
        send.getCarData = carData
    
    }
    
    
    @IBAction func pass(_ sender: Any) {
        performSegue(withIdentifier: "showCarLsit", sender: self)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

