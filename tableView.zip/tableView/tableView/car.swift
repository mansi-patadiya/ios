//
//  car.swift
//  tableView
//
//  Created by exam on 19/09/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class car: NSObject {
    var name = ""
    var price = 0

}
