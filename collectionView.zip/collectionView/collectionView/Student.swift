//
//  Student.swift
//  collectionView
//
//  Created by exam on 27/09/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class Student: NSObject {
    var name = ""
    var percentage = 0.0

}
