//
//  ViewController.swift
//  collectionView
//
//  Created by exam on 27/09/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let appdel = UIApplication.shared.delegate as! AppDelegate
    
    @IBOutlet weak var txtName: UITextField!
    
    @IBOutlet weak var txtPerc: UITextField!
    
    
    @IBAction func actionAdd(_ sender: Any) {
        let obj = Student()
        obj.name = txtName.text!
        obj.percentage = Double(txtPerc.text!)!
        appdel.arrayStudent.append(obj)
    }
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

