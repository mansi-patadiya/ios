//
//  MyCell.swift
//  collectionView
//
//  Created by exam on 27/09/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class MyCell: UICollectionViewCell {
    
}
