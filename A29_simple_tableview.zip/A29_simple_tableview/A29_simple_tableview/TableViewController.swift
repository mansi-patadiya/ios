//
//  TableViewController.swift
//  A29_simple_tableview
//
//  Created by exam on 10/7/22.
//  Copyright © 2022 gls. All rights reserved.
//

import UIKit

class TableViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    var appDel = UIApplication.shared.delegate as! AppDelegate
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appDel.stuArray.count
    }
    
//    Below method is for creating default tableview
    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        var cell = UITableViewCell(style: .subtitle, reuseIdentifier: "myCell")
//        cell.textLabel?.text=appDel.stuArray[indexPath.row].stuNAme
//        cell.detailTextLabel?.text=String(appDel.stuArray[indexPath.row].stuRollNo)
//        return cell
//    }
    
    
//    Below is for creating custom table view
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! myCell
        cell.name.text = appDel.stuArray[indexPath.row].stuNAme
        cell.rollno.text = String(appDel.stuArray[indexPath.row].stuRollNo)
        return cell
    }
    // below is used to go to next page using delegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        appDel.index = indexPath.row
        performSegue(withIdentifier: "nextDelegate", sender: self)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
