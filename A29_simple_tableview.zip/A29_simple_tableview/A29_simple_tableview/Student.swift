//
//  Student.swift
//  A29_simple_tableview
//
//  Created by exam on 10/7/22.
//  Copyright © 2022 gls. All rights reserved.
//

import UIKit

class Student: NSObject {
    var stuNAme=""
    var stuRollNo=0
}
