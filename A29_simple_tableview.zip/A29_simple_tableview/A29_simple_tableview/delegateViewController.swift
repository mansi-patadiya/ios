//
//  delegateViewController.swift
//  A29_simple_tableview
//
//  Created by exam on 10/7/22.
//  Copyright © 2022 gls. All rights reserved.
//

import UIKit

class delegateViewController: UIViewController {
    @IBOutlet weak var name: UILabel!

    @IBOutlet weak var rollNo: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        var app = UIApplication.shared.delegate as! AppDelegate
        name.text = app.stuArray[app.index].stuNAme
        rollNo.text = String(app.stuArray[app.index].stuRollNo)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
